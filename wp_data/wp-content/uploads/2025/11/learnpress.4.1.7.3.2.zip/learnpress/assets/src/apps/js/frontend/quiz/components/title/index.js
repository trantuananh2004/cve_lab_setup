
const Title = () => {
	return <h3>The title</h3>;
};

export default Title;
