import searchThemesAddons from './addons/search-lp-addons-themes';

document.addEventListener( 'DOMContentLoaded', function( event ) {
	searchThemesAddons();
} );
