<?php
class LP_Course_Item_Lesson extends LP_Course_Item {
	public function __construct( $item, $args = null ) {
		parent::__construct( $item, $args );

	}
}
