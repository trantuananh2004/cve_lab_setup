<?php

defined( 'ABSPATH' ) || exit();

if ( ! class_exists( 'LP_Statistic_Plugin' ) ) {

	class LP_Statistic_Plugin {

		/**
		 * LearnPress statistic layout
		 *
		 * @since 2.0
		 */
		public static function render() {

		}



	}
}
